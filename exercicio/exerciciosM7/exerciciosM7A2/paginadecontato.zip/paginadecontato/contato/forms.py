
from django import forms

class ContatoForm (forms.Form) :
    nome = forms.CharField(label="Nome")
    email = forms.EmailField(label="Email")
    mensagem = forms.CharField(label="Mensagem",widget=forms.Textarea)

class reservaForm (forms.Form) :
    nomePet = forms.CharField(label="Pet")
    telefone = forms.CharField(label="Telefone")
    data = forms.DateField(label="Data")
    mensagem = forms.CharField(label="Observação",widget=forms.Textarea)