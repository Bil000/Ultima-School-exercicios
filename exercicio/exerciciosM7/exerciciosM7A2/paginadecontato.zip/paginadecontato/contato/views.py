from pdb import post_mortem
import re
from django.shortcuts import render
from django.http import HttpResponse
from contato.forms import ContatoForm, reservaForm

def inicio(request) :
    resposta = render(request, "inicio.html")
    return resposta

def contato(request) :
    sucesso = False
    if request.method == 'GET' :
        form = ContatoForm()
    else :
        form = ContatoForm(request.POST)
        if form.is_valid() :
           sucesso = True 

    agenda = {
        'telefone' : "(00)00000-0000",
        'responsavel' : "Maria",
        'form' : form,
        'sucesso' : sucesso
    }
  
    resposta = render(request, "contato.html", agenda)
    return resposta

def reserva(request) :
    sucesso = False
    if request.method == 'GET' :
        form = reservaForm()
    else :
        form = reservaForm(request.POST)
        if form.is_valid() :
           sucesso = True 

    contexto = {
        'form' : form,
        'sucesso' : sucesso
    }

    reposta = render(request, "reservas.html", contexto)
    return reposta




