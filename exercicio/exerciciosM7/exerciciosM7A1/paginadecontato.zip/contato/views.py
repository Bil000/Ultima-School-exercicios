import re
from django.shortcuts import render
from django.http import HttpResponse

def inicio(request) :
    resposta = render(request, "index.html")
    return resposta

